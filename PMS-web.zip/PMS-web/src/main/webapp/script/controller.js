app.controller("myCtrl", function($scope, $http) {
		$scope.getCategories = function() {
			var url = 'http://localhost:8080/PMS-web/CategoryServlet';
			$http.get(url).success(function(response) {
				$scope.categories = response;
			}).error(function(msg) {
				$scope.emps = msg;
			});
		};

		$scope.getSubCategories = function() {
			var url = 'http://localhost:8080/PMS-web/SubCategoryServlet';
			$http.get(url).success(function(response) {
				$scope.cats = response;
			}).error(function(msg) {
				$scope.cats = msg;
			});

		};
		$scope.getDiscounts = function() {
			var url = 'http://localhost:8080/PMS-web/DiscountServlet';
			$http.get(url).success(function(response) {
				$scope.discounts = response;
			}).error(function(msg) {
				$scope.cats = msg;
			});

		};
		$scope.getSupplier = function() {
			var url = 'http://localhost:8080/PMS-web/SupplierServlet';
			$http.get(url).success(function(response) {
				$scope.sup = response;
			}).error(function(msg) {
				$scope.cats = msg;
			});

		};
		
		$scope.getProducts = function() {
			var url = 'http://localhost:8080/PMS-web/listServlet';
			$http.get(url).success(function(response){
				$scope.products = response;
			}).error(function(msg) {
				$scope.products = msg;
			});

		};
	});

app.controller("searchCtrl",function($scope,$http){
	
	
	$http.get('http://localhost:8080/PMSweb/searchservlet')
		.success(function(response){
			$scope.search=response;
		})
		.error(function(errMsg){
			$scope.search=errMsg;
		});
	
	
	
});


app.controller("listCtrl",function($scope,$http){
	
	
	$http.get('http://localhost:8080/PMS-web/listServlet')
		.success(function(response){
			$scope.products=response;
		})
		.error(function(errMsg){
			$scope.errmsg=errMsg;
		});
	
	
});
