package com.flp.pms.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.pms.domain.Category;
import com.flp.pms.domain.Discount;
import com.flp.pms.domain.SubCategory;
import com.flp.pms.domain.Supplier;
import com.flp.pms.service.ProductServiceImpl;
import com.google.gson.Gson;

public class CategoryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public CategoryServlet() {
        super();
      
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("application/json");
		PrintWriter out=response.getWriter();

		
		
		ProductServiceImpl impl= new ProductServiceImpl();
		
		List<Category> categories=impl.getAllCategory();

		Gson myJson=new Gson();

		String empjson=myJson.toJson(categories);
		out.println(empjson);
		
		
		
		
		
		
		
		
	}

}
