package com.flp.pms.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.pms.domain.Category;
import com.flp.pms.domain.Discount;
import com.flp.pms.domain.Product;
import com.flp.pms.domain.SubCategory;
import com.flp.pms.domain.Supplier;
import com.flp.pms.service.IProductService;
import com.flp.pms.service.ProductServiceImpl;

public class SaveProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public SaveProductServlet() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		IProductService impl = new ProductServiceImpl();
		PrintWriter out = response.getWriter();

		String name = request.getParameter("name");
		String description = request.getParameter("description");
		String mfdate = request.getParameter("mfdate");
		String exdate = request.getParameter("exdate");
		String quantity = request.getParameter("quantity");
		String ratings = request.getParameter("ratings");
		String price = request.getParameter("price");
		String category = request.getParameter("category");
		String subcategory = request.getParameter("subcategory");
		String supplier = request.getParameter("supplier");
		String[] discounts = request.getParameterValues("discount");
		/*
		 * String pdiscounts=""; for(String str:discounts) pdiscounts+=str+",";
		 */
		/*
		 * String[]
		 * qualification=request.getParameterValues("chkQualification"); String
		 * qalify=""; for(String str:qualification) qalify+=str+",";
		 */
		Product product = new Product();
		product.setProductName(name);
		product.setDescription(description);
		/*
		 * employee.setEmail(email);
		 * employee.setSalary(Double.parseDouble(salary));
		 */

		SimpleDateFormat myFormat = new SimpleDateFormat("yyyy-MM-dd");
		/*
		 * Date pmfdate=null; Date pexdate=null;
		 */

		try {
			product.setManufacturing_date(myFormat.parse(mfdate));
			product.setExpiry_date(myFormat.parse(exdate));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} // dd-MMM-yyyy
			// dd-MMM-yyyy
		product.setQuantity(Integer.parseInt(quantity));
		product.setRatings(Float.parseFloat(ratings));
		product.setMax_retail_price(Double.parseDouble(price));
		Category category2 = new Category();
		category2.setCategory_Id(Integer.parseInt(category));
		product.setCategory(category2);
		SubCategory subCategory2 = new SubCategory();
		subCategory2.setSub_category_Id(Integer.parseInt(subcategory));
		product.setSubCategory(subCategory2);
		Supplier supplier2 = new Supplier();
		supplier2.setSupplierId(Integer.parseInt(supplier));
		product.setSupplier(supplier2);

		List<Discount> discounts2 = impl.getAllDiscounts();
		List<Discount> discounts3 = new ArrayList<>();
		int len = discounts.length;
		int i = 0;
		// Discount discount=new Discount();
		for (Discount dis : discounts2) {

			if (i < len) {
				if (dis.getDiscountName().equalsIgnoreCase(discounts[i])) {
					discounts3.add(dis);
					i++;
				}
			}
			product.setDiscounts(discounts3);
		}

		impl.addProduct(product);
		out.println(product);
	}
}