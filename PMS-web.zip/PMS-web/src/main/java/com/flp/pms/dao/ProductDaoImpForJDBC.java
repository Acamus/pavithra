package com.flp.pms.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.flp.pms.domain.Category;
import com.flp.pms.domain.Discount;
import com.flp.pms.domain.Product;
import com.flp.pms.domain.SubCategory;
import com.flp.pms.domain.Supplier;
import com.flp.pms.view.UserInteraction;

public class ProductDaoImpForJDBC implements IProductDao {
	/* UserInteraction userInteraction=new UserInteraction(); */
	// To eastablish connection 
	
	public Connection getMySQLConnection() {
		Connection conn = null;

		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/pmsdb", "root", "India123");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		return conn;
	}
	// To retrieve Categories.

	
	public List<Category> getAllCategory() {
		List<Category> categories = new ArrayList<Category>();
		Category category = null;

		Connection conn = getMySQLConnection();
		PreparedStatement ps = null;
		try {
			ps = conn.prepareStatement("select *from Category");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				category = new Category();
				category.setCategory_Id(rs.getInt(1));
				category.setCategory_Name(rs.getString(2));
				category.setDescription(rs.getString(3));

				categories.add(category);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				ps.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return categories;
	}

	
	public List<SubCategory> getAllSubCategory() {
		List<SubCategory> subCategories = new ArrayList<SubCategory>();
		SubCategory subCategory = null;
		Connection conn = getMySQLConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement("select *from SubCategory");
			rs = ps.executeQuery();
			while (rs.next()) {
				subCategory = new SubCategory();
				subCategory.setSub_category_Id(rs.getInt(1));
				subCategory.setSub_category_Name(rs.getString(2));
				int catId = rs.getInt(3);
				List<Category> categories = getAllCategory();
				for (Category category : categories) {
					if (category.getCategory_Id() == catId) {
						subCategory.setCategory(category);
					}

				}
				subCategories.add(subCategory);

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				ps.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return subCategories;
	}

	
	public List<Supplier> getAllSuppliers() {
		List<Supplier> suppliers = new ArrayList<Supplier>();
		Connection conn = getMySQLConnection();
		PreparedStatement ps = null;
		Supplier supplier = null;
		try {
			ps = conn.prepareStatement("select *from Supplier");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				supplier = new Supplier();
				supplier.setSupplierId(rs.getInt(1));
				supplier.setFirstName(rs.getString(2));
				supplier.setLastName(rs.getString(3));
				supplier.setAddress(rs.getString(4));
				supplier.setCity(rs.getString(5));
				supplier.setState(rs.getString(6));
				supplier.setPincode(rs.getString(7));
				supplier.setContactno(rs.getString(8));
				suppliers.add(supplier);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				ps.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return suppliers;
	}

	
	public List<Discount> getAllDiscounts() {
		List<Discount> discounts = new ArrayList<Discount>();
		Discount discount = null;
		Connection conn = getMySQLConnection();
		PreparedStatement ps = null;
		try {
			ps = conn.prepareStatement("select *from Discount");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				discount = new Discount();
				discount.setDiscountId(rs.getInt(1));
				discount.setDiscountName(rs.getString(2));
				discount.setDescription(rs.getString(3));
				discount.setDiscount_percentage(rs.getDouble(4));
				discount.setValidThru(rs.getDate(5));
				discounts.add(discount);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				ps.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return discounts;
	}

	
	public boolean addProduct(Product product) {

		Connection conn = getMySQLConnection();
		PreparedStatement ps1 = null;
		PreparedStatement ps = null;
		PreparedStatement pd = null;
		boolean flag = false;
		try {
			ps1 = conn.prepareStatement("insert into product_discount values(?,?)");
			ps = conn.prepareStatement(
					"insert into Product (productName,description,manufacturing_date,expiry_date,max_retail_price,category_Id,sub_category_Id,supplierId,quantity,ratings)values(?,?,?,?,?,?,?,?,?,?)");
			ps.setString(1, product.getProductName());
			ps.setString(2, product.getDescription());
			ps.setDate(3, new java.sql.Date(product.getManufacturing_date().getTime()));
			ps.setDate(4, new java.sql.Date(product.getExpiry_date().getTime()));
			ps.setDouble(5, product.getMax_retail_price());
			ps.setInt(6, product.getCategory().getCategory_Id());
			ps.setInt(7, product.getSubCategory().getSub_category_Id());
			ps.setInt(8, product.getSupplier().getSupplierId());
			ps.setInt(9, product.getQuantity());
			ps.setDouble(10, product.getRatings());
			int rows = ps.executeUpdate();
			if (rows > 0)
				flag = true;
			pd = conn.prepareStatement("select *from product");
			ResultSet rs = pd.executeQuery();
			int productId = 0;
			while (rs.next()) {
				productId = rs.getInt(1);
			}

			List<Discount> discounts = product.getDiscounts();
			for (Discount discount : discounts) {
				ps1.setInt(1, productId);
				ps1.setInt(2, discount.getDiscountId());
				ps1.executeUpdate();

			}
			// ps1.setInt(productId, x);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				pd.close();
				ps.close();
				ps1.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
System.out.println(product);
		return flag;

	}

	/*
	 * @Override public Map<Integer, Product> getAllProducts() { // TODO
	 * Auto-generated method stub return null; }
	 */
	// Delete product
	
	public boolean deleteProduct(int productId) {
		Connection conn = getMySQLConnection();
		PreparedStatement ps1 = null;
		Boolean flag = false;
		int count = 0;
		try {
			ps1 = conn.prepareStatement("delete from product_discount where productId=?");
			ps1.setInt(1, productId);
			ps1.executeUpdate();
			PreparedStatement ps = conn.prepareStatement("delete from product where productId=?");

			ps.setInt(1, productId);
			count = ps.executeUpdate();

			if (count > 0)
				flag = true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {

				ps1.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return flag;

	}

	// view all Products

	public List<Product> getAllProducts() {

		Connection conn = getMySQLConnection();
		PreparedStatement ps = null;
		PreparedStatement ps2 = null;
		Product product = null;
		List<Product> products = new ArrayList<Product>();
		try {
			ps = conn.prepareStatement("select *from product");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				product = new Product();
				product.setProductId(rs.getInt(1));
				product.setProductName(rs.getString(2));
				product.setDescription(rs.getString(3));
				product.setManufacturing_date(rs.getDate(4));
				product.setExpiry_date(rs.getDate(5));
				product.setMax_retail_price(rs.getDouble(6));
				int categoryId = rs.getInt(7);
				List<Category> categories = getAllCategory();
				for (Category category : categories) {
					if (category.getCategory_Id() == categoryId) {
						product.setCategory(category);
						break;
					}

				}
				int subCategoryId = rs.getInt(8);
				List<SubCategory> subCategories = getAllSubCategory();
				for (SubCategory subCategory : subCategories) {
					if (subCategory.getSub_category_Id() == subCategoryId) {
						product.setSubCategory(subCategory);
						break;
					}
				}
				int supplierId = rs.getInt(9);
				List<Supplier> suppliers = getAllSuppliers();
				for (Supplier supplier : suppliers) {
					if (supplier.getSupplierId() == supplierId) {
						product.setSupplier(supplier);
						break;
					}
				}
				product.setQuantity(rs.getInt(10));
				product.setRatings(rs.getFloat(11));
				/* System.out.println(product.getProductId()); */
				ps2 = conn.prepareStatement("select *from  product_discount where productId=?");
				ps2.setInt(1, product.getProductId());
				ResultSet rs1 = ps2.executeQuery();
				List<Discount> discounts = getAllDiscounts();
				List<Discount> discounts2 = new ArrayList<Discount>();
				while (rs1.next()) {
					for (Discount discount : discounts) {
						if (discount.getDiscountId() == rs1.getInt(2)) {
							discounts2.add(discount);

						}

					}

				}
				product.setDiscounts(discounts2);

				products.add(product);

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				ps2.close();
				ps.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return products;
	}
	// Update product name

	
	public void updateProductName(String productName, int productId) {
		Connection conn = getMySQLConnection();
		try {
			PreparedStatement ps = conn.prepareStatement("update product set productName=? where productId=?");
			ps.setString(1, productName);
			ps.setInt(2, productId);
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}


	public void updateProductExpDate(java.util.Date expiryDate, int productId) {
		Connection conn = getMySQLConnection();
		PreparedStatement ps=null;
		try {
			 ps = conn.prepareStatement("update product set expiry_date=? where productId=?");
		
			ps.setDate(1, new java.sql.Date(expiryDate.getTime()));
			ps.setInt(2, productId);
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}


	public void updateProductMaxRetailPrice(double mRP, int productId) {
		Connection conn = getMySQLConnection();
		try {
			PreparedStatement ps = conn.prepareStatement("update product set max_retail_price=? where productId=?");
			ps.setDouble(1, mRP);
			ps.setInt(2, productId);
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}


	public void updateProductRating(float rating, int productId) {
		Connection conn = getMySQLConnection();
		try {
			PreparedStatement ps = conn.prepareStatement("update product set ratings=? where productId=?");
			ps.setDouble(1, rating);
			ps.setInt(2, productId);
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}


	public void updateProductCategory(int Category_Id, int productId) {
		Connection conn = getMySQLConnection();
		try {
			PreparedStatement ps = conn.prepareStatement("update product set category_Id=? where productId=?");
			ps.setDouble(1, Category_Id);
			ps.setInt(2, productId);
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}


	@Override
	public void storeJson(String namejson) {
		Connection conn=null;
		PreparedStatement preparedStatement=null;
		PreparedStatement preparedStatement2=null;
		String sql="delete from jsondata";
		String sql1="insert into jsondata values (?)";
		conn=getMySQLConnection();
		try
		{
			preparedStatement=conn.prepareStatement(sql);
			preparedStatement.executeUpdate();
			preparedStatement2=conn.prepareStatement(sql1);
			preparedStatement2.setString(1, namejson);
			preparedStatement2.executeUpdate();
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		
	
		
	}


	@Override
	public String getJson() {
		Connection conn=null;
		PreparedStatement preparedStatement=null;
		String sql="select * from jsondata";
		conn=getMySQLConnection();
		ResultSet rs=null;
		String jsonData="";
		try
		{
			preparedStatement=conn.prepareStatement(sql);
			rs=preparedStatement.executeQuery();
			if(rs.next())
				jsonData=rs.getString(1);
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		
		return jsonData;
	}

}
