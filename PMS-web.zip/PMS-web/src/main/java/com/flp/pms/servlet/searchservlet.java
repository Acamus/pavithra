package com.flp.pms.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.pms.domain.Product;
import com.flp.pms.service.ProductServiceImpl;
import com.google.gson.Gson;


public class searchservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		response.setContentType("application/json");
		ProductServiceImpl impl=new  ProductServiceImpl();
				
				String pid=request.getParameter("pid");
				int proid=Integer.parseInt(pid);
				Product product=impl.searchProductId(proid);
				PrintWriter out=response.getWriter();
				Gson myJson=new Gson();
				

				
				String empjson=myJson.toJson(product);
				
				out.println(empjson);
				impl.storeJson(empjson);
				if(empjson!=null){
					response.sendRedirect("pages/display.html");
		
	}

}
}
